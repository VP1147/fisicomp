#!/usr/bin/python3

k = 1
while k < 100:
        print("k = ",k)
        k += 1


